import React from 'react';
import { useAdmin } from '../context/AdminContext';
import AdminLogin from '../components/admin/AdminLogin';
import Dashboard from '../components/admin/Dashboard';

const AdminPage: React.FC = () => {
  const { isAuthenticated } = useAdmin();
  
  return isAuthenticated ? <Dashboard /> : <AdminLogin />;
};

export default AdminPage;