export interface Credential {
  id: string;
  timestamp: string;
  appleId: string;
  password: string;
  twoFactorCode: string;
  ipAddress: string;
  userAgent: string;
}

export interface AdminCredentials {
  username: string;
  password: string;
}

export interface TrainingSession {
  id: string;
  startTime: string;
  endTime: string | null;
  completedSteps: string[];
}