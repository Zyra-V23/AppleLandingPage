import React from 'react';
import { useAuth } from '../../context/AuthContext';

const ErrorMessage: React.FC = () => {
  const { resetAuth } = useAuth();
  
  return (
    <div className="w-full max-w-md">
      <div className="mb-8 flex justify-center">
        <div className="relative">
          <svg className="w-32 h-32" viewBox="0 0 200 200">
            <defs>
              <linearGradient id="dotGradient1" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#FF9500" />
                <stop offset="100%" stopColor="#FF2D55" />
              </linearGradient>
              <linearGradient id="dotGradient2" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#FF2D55" />
                <stop offset="100%" stopColor="#AF52DE" />
              </linearGradient>
              <linearGradient id="dotGradient3" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#5856D6" />
                <stop offset="100%" stopColor="#007AFF" />
              </linearGradient>
              <linearGradient id="dotGradient4" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#32D74B" />
                <stop offset="100%" stopColor="#64D2FF" />
              </linearGradient>
            </defs>
            {/* Animated dots around the Apple logo */}
            {Array.from({ length: 60 }).map((_, i) => {
              const angle = (i * 6) * Math.PI / 180;
              const x = 100 + 70 * Math.cos(angle);
              const y = 100 + 70 * Math.sin(angle);
              const gradientIndex = Math.floor(i / 15) + 1;
              
              return (
                <circle 
                  key={i} 
                  cx={x} 
                  cy={y} 
                  r={3} 
                  fill={`url(#dotGradient${gradientIndex})`}
                  opacity={0.8}
                />
              );
            })}
            {/* Apple Logo */}
            <g transform="translate(80, 75) scale(0.2)">
              <path d="M213.803 167.03c.698 7.7 2.086 15.7 5.263 24.501-22.058 9.996-54.218-7.7-54.218-43.615 0-28.302 25.564-40.99 49.652-41.464-1.214 6.3-2.086 14.487-2.086 24.133 0 12.253.679 25.395 1.39 36.445zm50.403 77.575c-12.98 0-33.542-17.695-50.054-49.825-.335 1.214-.67 2.428-1.004 3.642-7.002 25.216-15.353 50.432-37.411 50.432-16.476 0-26.099-10.132-34.145-21.894-3.441-5.01-6.513-10.286-9.444-15.353 28.97-22.94 49.472-55.918 49.472-85.97 0-19.26-5.263-34.83-14.001-45.689 9.785-9.108 20.63-13.862 33.611-13.862 14.68 0 23.79 7.527 33.965 16.204 6.84 5.87 14.187 12.181 23.79 16.568.156 10.649.156 24.15.156 41.303 0 46.33-.156 85.616-10.498 106.605 4.966-1.22 10.372-2.08 16.567-2.08 48.13 0 93.137 40.959 96.273 63.445-13.676 11.065-55.432 24.32-95.387 24.32-12.825 0-24.15-2.08-34.145-5.87-11.871-3.948-23.277-9.65-33.29-17.538 41.79-3.084 57.518-35.884 65.544-64.152zm-125.325-5.262c-1.39-3.292-2.779-6.583-4.04-9.875 20.296-20.473 33.795-42.19 33.795-60.667 0-11.18-4.613-19.774-13.148-25.98 3.97-7.506 10.663-13.497 22.383-14.344-.67 2.779-1.12 5.557-1.12 8.51 0 21.535 17.09 57.839 49.304 81.892-1.004 3.441-2.086 6.76-3.09 9.929-9.802 29.998-18.592 56.79-57.12 61.497-4.594-17.873-13.497-36.908-26.964-51.465v.503zm223.347 54.54c-5.51 0-9.968-4.458-9.968-9.968 0-5.51 4.458-9.967 9.968-9.967 5.51 0 9.968 4.457 9.968 9.967 0 5.51-4.458 9.967-9.968 9.967z" fill="currentColor" />
            </g>
          </svg>
        </div>
      </div>
      
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
        <h1 className="text-xl font-semibold text-red-600 mb-2">Authentication Error</h1>
        <p className="text-red-600">
          Your Apple ID or password was incorrect. Please try again.
        </p>
      </div>
      
      <div className="text-center">
        <button
          onClick={resetAuth}
          className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition"
        >
          Try Again
        </button>
      </div>
      
      <div className="mt-6 text-center space-y-2">
        <a href="#" className="text-blue-500 text-sm hover:underline">
          Forgot password?
        </a>
        <div>
          <a href="#" className="text-blue-500 text-sm hover:underline">
            Create Apple Account
          </a>
        </div>
      </div>
    </div>
  );
};

export default ErrorMessage;