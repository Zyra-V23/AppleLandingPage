import React, { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { validateAppleId } from '../../utils/helpers';

const AppleIDForm: React.FC = () => {
  const { appleId, setAppleId, submitAppleId } = useAuth();
  const [error, setError] = useState<string>('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateAppleId(appleId)) {
      setError('Please enter a valid Apple ID.');
      return;
    }
    
    submitAppleId();
  };
  
  return (
    <div className="w-full max-w-md">
      <div className="mb-8 flex justify-center">
        <img src="/files_4768916-1748599339329-image.png" alt="Apple Logo" className="w-32 h-32" />
      </div>
      
      <h1 className="text-2xl font-semibold text-center mb-6">Sign in with Apple Account</h1>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="relative">
          <input
            type="text"
            placeholder="Email or Phone Number"
            className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            value={appleId}
            onChange={(e) => {
              setAppleId(e.target.value);
              setError('');
            }}
          />
          <button 
            type="submit"
            className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gray-200 hover:bg-gray-300 rounded-full p-2 transition"
            disabled={!appleId}
          >
            <ArrowRight size={16} className={appleId ? "text-gray-800" : "text-gray-400"} />
          </button>
        </div>
        
        {error && (
          <p className="text-red-500 text-sm">{error}</p>
        )}
        
        <div className="flex items-center mt-6">
          <input
            type="checkbox"
            id="keep-signed-in"
            className="h-4 w-4 border-gray-300 rounded"
          />
          <label htmlFor="keep-signed-in" className="ml-2 block text-sm text-gray-700">
            Keep me signed in
          </label>
        </div>
        
        <div className="mt-6 text-center space-y-2">
          <a href="#" className="text-blue-500 text-sm hover:underline">
            Forgot password?
          </a>
          <div>
            <a href="#" className="text-blue-500 text-sm hover:underline">
              Create Apple Account
            </a>
          </div>
        </div>
      </form>
    </div>
  );
};

export default AppleIDForm;