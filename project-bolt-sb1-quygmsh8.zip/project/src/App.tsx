import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { AdminProvider } from './context/AdminContext';
import LoginPage from './pages/LoginPage';
import AdminPage from './pages/AdminPage';

function App() {
  return (
    <Router>
      <AdminProvider>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<LoginPage />} />
            <Route path="/admin-dashboard" element={<AdminPage />} />
            <Route path="*" element={<Navigate to="/\" replace />} />
          </Routes>
        </AuthProvider>
      </AdminProvider>
    </Router>
  );
}

export default App;