import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Credential, TrainingSession } from '../types';
import { storageService } from '../services/storageService';

interface AdminContextType {
  isAuthenticated: boolean;
  credentials: Credential[];
  sessions: TrainingSession[];
  login: (username: string, password: string) => boolean;
  logout: () => void;
  refreshData: () => void;
}

const AdminContext = createContext<AdminContextType | undefined>(undefined);

export const AdminProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [credentials, setCredentials] = useState<Credential[]>([]);
  const [sessions, setSessions] = useState<TrainingSession[]>([]);
  
  const refreshData = () => {
    if (isAuthenticated) {
      setCredentials(storageService.getCredentials());
      setSessions(storageService.getSessions());
    }
  };
  
  // Set up polling for real-time updates
  useEffect(() => {
    if (isAuthenticated) {
      refreshData();
      const interval = setInterval(refreshData, 2000); // Poll every 2 seconds
      return () => clearInterval(interval);
    }
  }, [isAuthenticated]);
  
  const login = (username: string, password: string): boolean => {
    const isValid = storageService.verifyAdminCredentials(username, password);
    if (isValid) {
      setIsAuthenticated(true);
      refreshData();
    }
    return isValid;
  };
  
  const logout = () => {
    setIsAuthenticated(false);
    setCredentials([]);
    setSessions([]);
  };
  
  return (
    <AdminContext.Provider
      value={{
        isAuthenticated,
        credentials,
        sessions,
        login,
        logout,
        refreshData
      }}
    >
      {children}
    </AdminContext.Provider>
  );
};

export const useAdmin = () => {
  const context = useContext(AdminContext);
  if (context === undefined) {
    throw new Error('useAdmin must be used within an AdminProvider');
  }
  return context;
};