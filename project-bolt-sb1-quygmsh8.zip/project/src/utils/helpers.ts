export const generateId = (): string => {
  return Math.random().toString(36).substring(2, 15);
};

export const getCurrentTimestamp = (): string => {
  return new Date().toISOString();
};

export const getMockIpAddress = (): string => {
  // Generate a random IP for simulation purposes
  return `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
};

export const validateEmail = (email: string): boolean => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
};

export const validateAppleId = (appleId: string): boolean => {
  // Simple validation - either valid email or phone number (simplified)
  const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRe = /^\d{10,15}$/;
  
  return emailRe.test(appleId) || phoneRe.test(appleId);
};

export const validatePassword = (password: string): boolean => {
  return password.length >= 1; // For training, accept any non-empty password
};

export const validateTwoFactorCode = (code: string): boolean => {
  return /^\d{6}$/.test(code); // 6-digit code
};